var stage = document.getElementById('stage');
var menu = document.getElementById('menu');

function generateIframe() {
    var url = document.getElementById('url').value.trim();
    if (!url) return;
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;

    var old = stage.querySelector('iframe');
    if (old) old.remove();

    var iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.allow = 'fullscreen; autoplay; clipboard-write; gamepad';
    stage.appendChild(iframe);

    menu.style.display = 'none';
    stage.style.display = 'block';

    // Must run right after the click / Enter, or the browser refuses it.
    var el = document.documentElement;
    if (el.requestFullscreen) el.requestFullscreen().catch(function () {});
    iframe.focus();
}

function closeIframe() {
    var iframe = stage.querySelector('iframe');
    if (iframe) iframe.remove();
    stage.style.display = 'none';
    menu.style.display = '';
    if (document.fullscreenElement) document.exitFullscreen();
}

document.getElementById('go').addEventListener('click', generateIframe);
document.getElementById('close').addEventListener('click', closeIframe);
document.getElementById('url').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        generateIframe();
    }
});
