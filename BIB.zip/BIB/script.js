function generateIframe() {
      var url = document.getElementById('url').value.trim();
      if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
      var iframe = document.createElement('iframe');
      iframe.src = url;
      iframe.allow = 'fullscreen; autoplay; clipboard-write; gamepad';
      iframe.allowFullscreen = true;
      iframe.style.cssText = 'display:block;width:100%;height:85vh;border:0';
      document.body.appendChild(iframe);
  }

document.getElementById('url').addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
          event.preventDefault();
          generateIframe();
      }
  });